// myProducts.filter((item)=>item.title.includes(search.value))

// myCartProductArray = myProducts.filter((item)=> myCartIDs.includes(item.id))
let fname = document.getElementById("fname");
let lname = document.getElementById("lname");
let email = document.getElementById("email");
let password = document.getElementById("password");
let confirmPassword = document.getElementById("confirmPassword");
let error = document.getElementById("error");

document.getElementById("signup").addEventListener("click", (e) => {
    if (
        fname.value === "" ||
        lname.value === "" ||
        email.value === "" ||
        password.value === "" ||
        confirmPassword.value === ""
    ) {
        error.textContent = "Please enter all required fields";
        return;
    } else if (password.value !== confirmPassword.value) {
        error.textContent = "Password and confirm password do not match";
        return;
    }
    //signup
    let users = JSON.parse(localStorage.getItem("users")) || [];
    let filteredUsers = users.filter((user) => user.email == email.value);
    if (filteredUsers.length > 0) {
        error.textContent = "user already exists!";
    } else {
        users.push({
            fname: fname.value,
            lname: lname.value,
            email: email.value,
            password: password.value,
            createdAt: new Date(),
        });

        localStorage.setItem("users", JSON.stringify(users));
        window.location.href = "./login.html";
    }
});
