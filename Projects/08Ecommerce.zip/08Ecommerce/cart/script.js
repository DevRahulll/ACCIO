if (!localStorage.getItem("currentUser")) {
    window.location.href = "../login.html";
}

function showCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    if (cart.length === 0) {
        document.getElementById("cart").innerHTML =
            "<p>Your cart is empty.</p>";
        document.getElementById("summary").innerHTML = "";
        return;
    }

    let html = "";
    let total = 0;

    for (let i = 0; i < cart.length; i++) {
        total += cart[i].price;
        html += `
        <div class="cart-item">
            <img src="${cart[i].image}" alt="${cart[i].title}"/>
        <div class="details">
            <p>Title : ${cart[i].title}</p>
            <p>Price : ${cart[i].price}</p>
        </div>
        <button onclick="removeItem(${i})">Remove From Cart</button>
        </div>
        `;
    }

    document.getElementById("cart").innerHTML = html;
    document.getElementById("summary").innerHTML =
        '<p class="total">Total : $' +
        total.toFixed(2) +
        "</p>" +
        '<a class="btn" href="../razorpay/index.html">Checkout</a>';
}

//item is the pos of th eitem in the cart array

function removeItem(item) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(item, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    showCart();
}

showCart();
