if (!localStorage.getItem("currentUser")) {
    window.location.href = "../login.html";
}

let allProducts = [];
let category = "all";
let colorNames = ["red", "blue", "green", "black", "white"];
let colorCodes = {
    red: "#e11d48",
    blue: "#4938af",
    green: "#203d3e",
    black: "#000000",
    white: "#ffffff",
};
let sizeNames = ["S", "M", "L", "XL"];

// this names used by fakestoreApi
let categories = [
    ["men's clothing", "Men's Clothing"],
    ["women's clothing", "Women's Clothing"],
    ["jewelery", "Jewellery"],
    ["electronics", "Electronics"],
];

fetch("https://fakestoreapi.com/products")
    .then((res) => res.json())
    .then((data) => {
        //adding color and size to api response
        data.forEach(function (p) {
            p.colors = ["black", "blue", "green"];

            if (p.category.includes("clothing")) {
                p.sizes = ["S", "M", "L"];
            } else {
                p.sizes = [];
            }
        });

        allProducts = data;
        //display
        showProducts();
    });

function getChecked(name) {
    let values = [];
    let boxes = document.querySelectorAll('input[name="' + name + '"]:checked');
    for (let i = 0; i < boxes.length; i++) {
        values.push(boxes[i].value);
    }
    return values;
}

function showProducts() {
    let searchText = document.getElementById("search").value.toLowerCase();
    let colors = getChecked("color");
    let sizes = getChecked("size");
    let prices = getChecked("price");
    let minRating = Number(document.getElementById("rating").value);

    let filtered = allProducts.filter(function (p) {
        if (!p.title.toLowerCase().includes(searchText)) return false;

        if (category !== "all" && p.category !== category) return false;

        if (p.rating.rate < minRating) return false;

        if (colors.length > 0 && !p.colors.some((c) => colors.includes(c)))
            return false;
        if (sizes.length > 0 && !p.sizes.some((s) => sizes.includes(s)))
            return false;

        if (prices.length > 0) {
            let inRange = false;
            for (let i = 0; i < prices.length; i++) {
                let range = prices[i].split("-"); // 25-50
                if (p.price >= Number(range[0]) && p.price < Number(range[1])) {
                    inRange = true;
                }
            }
            if (!inRange) return false;
        }
        return true;
    });

    let html = "";
    for (let i = 0; i < categories.length; i++) {
        let items = filtered.filter((p) => p.category === categories[i][0]);
        if (items.length === 0) continue;

        html += '<h3 class="category-title">' + categories[i][1] + "</h3>";
        html += '<div class="items">';
        for (let j = 0; j < items.length; j++) {
            html += productCard(items[j]);
        }
        html += "</div>";
    }

    if (html === "") html = "<p>No products found.</p>";
    document.getElementById("products").innerHTML = html;
}

function productCard(p) {
    let circles = "";
    for (let i = 0; i < p.colors.length; i++) {
        circles +=
            '<span class="circle" style="background-color:' +
            colorCodes[p.colors[i]] +
            '"></span';
    }

    return `
        <div class="item">
        <img src="${p.image}" alt="${p.title}"/>
        <div class="info">
            <div class="name">${p.title}</div>
            <div class="row">$${p.price}</span><span>${p.prizes.join(",")}</span></div>
            <div class="row"><span>Colors:</span><span>${circles}</span></div>
        <div>Rating: <span class="stars">${"★".repeat(Math.round(p.rating.rate))}</span></div>
        </div>
        <button onclick="addToCart(${p.id})">Add To Cart</button>
        </div>
        `;
}

function setCategory(button) {
    category = button.dataset.category;
    let buttons = document.querySelectorAll(".filter");
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].classList.remove("active");
    }
    button.classList.add("active");
    showProducts();
}

function addToCart(id) {
    let product = allProducts.find((p) => p.id === id);
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({
        id: product.id,
        title: product.title,
        price: product.price,
        image: product.image,
    });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Added to cart");
}

document.getElementById("search").addEventListener("input", showProducts);
document.getElementById("applyFilter").addEventListener("click", showProducts);
document.getElementById("rating").addEventListener("input", function () {
    document.getElementById("ratingValue").textContent = this.value;
});
