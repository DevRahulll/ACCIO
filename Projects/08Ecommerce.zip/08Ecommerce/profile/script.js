// Write your script here
let currUser = localStorage.getItem("currentUser");
if (!currUser) {
    window.location.href = "../login.html";
}

let message = document.getElementById("message");

//find logeed in user inside the saved users list

function findUserIndex(users) {
    for (let i = 0; i < users.length; i++) {
        if (users[i].email === currUser.email) return i;
    }
    return -1;
}

let users = JSON.parse(localStorage.getItem("users")) || [];
let index = findUserIndex(users);

//show the saved details in the form
document.getElementById("fname").value = users[index].fname;
document.getElementById("lname").value = users[index].lname;
document.getElementById("email").value = users[index].email;

document.getElementById("save").addEventListener("click", function () {
    let fname = document.getElementById("fname").value;
    let lname = document.getElementById("lname").value;
    if (fname === "" || lname === "") {
        message.className = "error";
        message.textContent = "Name cannot be empty";
        return;
    }
    users[index].fname = fname;
    users[index].lname = lname;
    localStorage.setItem("users", JSON.stringify(users));
    message.className = "success";
    message.textContent = "Profile updated";
});

document
    .getElementById("changePassword")
    .addEventListener("click", function () {
        let oldPassword = document.getElementById("oldPassword").value;
        let newPassword = document.getElementById("newPassword").value;
        let confirmPassword = document.getElementById("confirmPassword").value;

        if (oldPassword !== users[index].password) {
            message.className = "error";
            message.textContent = "Old password is wrong";
        } else if (newPassword === "" || newPassword !== confirmPassword) {
            message.className = "error";
            message.textContent =
                "New password and confirm password must match";
        } else {
            users[index].password = newPassword;
            localStorage.setItem("users", JSON.stringify(users));
            message.className = "success";
            message.textContent = "Password updated";
        }
    });

document.getElementById("logout").addEventListener("click", function () {
    localStorage.removeItem("currentUser");
    window.location.href = "../login.html";
});
