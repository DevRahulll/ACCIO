let email = document.getElementById("email");
let password = document.getElementById("password");
let error = document.getElementById("error");

function generateToken() {
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

document.getElementById("login").addEventListener("click", () => {
    //validation
    if (email.value === "" || password.value === "") {
        error.textContent = "Please enter email and password";
        return;
    }

    let users = JSON.parse(localStorage.getItem("users")) || [];
    let foundUser = null;

    for (let i = 0; i < users.length; i++) {
        if (users[i].email === email.value) {
            foundUser = users[i];
        }
    }

    if (foundUser === null) {
        error.textContent = "No Account found. Please sign up first";
        return;
    }

    if (foundUser.password !== password.value) {
        error.textContent = "Wrong password";
        return;
    }

    localStorage.setItem(
        "currentUser",
        JSON.stringify({ email: foundUser.email, token: generateToken() }),
    );
    window.location.href = "./shop/index.html";
});
